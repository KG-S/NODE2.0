const express = require("express");
const app = express();


app.get("/", function(req, res){
    res.sendFile(__dirname+"/html/index.html");
});
app.get("/Login", function(req, res){
    res.sendfile(__dirname+"/html/login.html");
});
app.get('/blog/:nome', function(req, res){
    res.send(req.params);
});





app.listen(8080, function(){
    console.log("servidor rodando na url http://localhost:8080");
})

